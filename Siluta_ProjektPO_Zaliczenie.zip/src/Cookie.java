import java.time.LocalDate;
import java.util.ArrayList;

public class Cookie extends Breadstuff
{
    static LocalDate today = LocalDate.now();
    static ArrayList<Cookie> cookieList=new ArrayList<Cookie>();

    public Cookie(String kind, LocalDate expirationDate, boolean fresh, boolean cut, boolean bread,
                  boolean bun, boolean cake, boolean cookie, boolean sweet, boolean savoury)
    {
        this.kind = kind;
        this.expirationDate = expirationDate;
        this.fresh = fresh;
        this.cut = cut;
        this.bread = bread;
        this.bun = bun;
        this.cake = cake;
        this.cookie = cookie;
        this.sweet = sweet;
        this.savoury = savoury;
    }

    @Override
    public String toString()
    {
        return super.toString();
    }
}
