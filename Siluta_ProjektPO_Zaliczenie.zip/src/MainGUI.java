import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainGUI
{
    JFrame frame;
    JLabel label, label3, label4, labelCoNieDziala, mainPicture;
    JButton goNext;

    public static void main(String[] args) {
        new MainGUI();
    }

    public MainGUI()
    {
        frame= new JFrame();

        mainPicture = new JLabel(new ImageIcon("baker.png"));
        mainPicture.setBounds(140,0,310,310);
        frame.add(mainPicture);

        label = new JLabel();
        label.setBounds(100,270,400,50);
        label.setFont(new Font("DialogInput", Font.BOLD, 40));
        label.setText("HappyOven Bakery");
        frame.add(label);

        label3 = new JLabel();
        label3.setBounds(30,330,600,30);
        label3.setFont(new Font("DialogInput", Font.BOLD, 19));
        label3.setText("We are glad that you are using our application!");
        frame.add(label3);

        label4 = new JLabel();
        label4.setBounds(110,450,500,30);
        label4.setFont(new Font("DialogInput", Font.BOLD, 19));
        label4.setText("We wish you successful shopping");
        frame.add(label4);

        goNext = new JButton("Go to the store");
        goNext.setBounds(190,380,210,50);
        goNext.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goNext);
        goNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PanelShop();
            }
        });

        labelCoNieDziala= new JLabel();
        labelCoNieDziala.setBounds(150,550,500,30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600,550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
    }
}
