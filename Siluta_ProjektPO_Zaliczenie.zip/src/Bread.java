import java.time.LocalDate;
import java.util.ArrayList;

public class Bread extends Breadstuff
{
    public static ArrayList<Bread> breadList=new ArrayList<Bread>();

    public Bread(String kind, String flour, LocalDate expirationDate, boolean fresh, boolean cut, boolean bread,
                 boolean bun, boolean cake, boolean cookie, boolean sweet, boolean savoury)
    {
        this.kind = kind;
        this.flour = flour;
        this.expirationDate = expirationDate;
        this.fresh = fresh;
        this.cut = cut;
        this.bread = bread;
        this.bun = bun;
        this.cake = cake;
        this.cookie = cookie;
        this.sweet = sweet;
        this.savoury = savoury;
    }

    @Override
    public String toString()
    {
        return super.toString();
    }
}
