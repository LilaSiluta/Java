import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class PaymentPanel
{
    JFrame frame;
    JLabel cartPicture, cart2Picture, label, label3, label3_3, labelCoNieDziala;

    public PaymentPanel()
    {
        frame = new JFrame();
        ImageIcon icon=new ImageIcon("dollar.png");

        JButton goBack = new JButton("Back");
        goBack.setBounds(30,460,120,30);
        goBack.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goBack);
        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CartShop();
            }
        });

        cartPicture = new JLabel(new ImageIcon("cart.png"));
        cartPicture.setBounds(385,-10,200,200);
        frame.add(cartPicture);

        cart2Picture = new JLabel(new ImageIcon("cart2.png"));
        cart2Picture.setBounds(0,-10,200,200);
        frame.add(cart2Picture);

        label = new JLabel();
        label.setBounds(170, 200, 500, 30);
        label.setFont(new Font("DialogInput", Font.BOLD, 25));
        label.setText("Are You a student?");
        frame.add(label);

        label3 = new JLabel();
        label3.setBounds(40,340,400,30);
        label3.setFont(new Font("DialogInput", Font.BOLD, 22));
        label3.setVisible(false);
        frame.add(label3);

        label3_3 = new JLabel();
        label3_3.setBounds(450,340,500,30);
        label3_3.setFont(new Font("DialogInput", Font.BOLD, 25));
        label3_3.setVisible(false);
        frame.add(label3_3);

        JButton pay = new JButton("Pay");
        pay.setBounds(260,410,70,30);
        pay.setFont(new Font("DialogInput", Font.BOLD, 20));
        pay.setEnabled(false);
        frame.add(pay);
        pay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(null, "Thank You for shopping in our bakery!", "Pay", JOptionPane.INFORMATION_MESSAGE,icon);
                int choice2 = JOptionPane.showOptionDialog(null, "Thank You for shopping in our bakery!", "Pay", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, icon, null, null);
                if (choice2 ==JOptionPane.YES_OPTION)
                {
                    System.exit(1);
                }
            }
        });

        JButton yes = new JButton("YES");
        yes.setBounds(80,260,90,30);
        yes.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(yes);
        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                label3.setText("Total price with discount: ");
                if (TipsPanel.choice == 0)
                {
                    label3_3.setText(round(CartShop.cost-(0.2*CartShop.cost)+(0.05*CartShop.cost))+" $");
                }
                else
                {
                    label3_3.setText(round(CartShop.cost-0.2*CartShop.cost)+" $");
                }
                pay.setEnabled(true);
                label3.setVisible(true);
                label3_3.setVisible(true);
            }
        });

        JButton no = new JButton("NO");
        no.setBounds(400,260,90,30);
        no.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(no);
        no.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                label3.setText("Total price: ");
                if (TipsPanel.choice == 0)
                {
                    label3_3.setText(round(CartShop.cost+0.05*CartShop.cost)+" $");
                }
                else
                {
                    label3_3.setText(round(CartShop.cost)+" $");
                }
                pay.setEnabled(true);
                label3.setVisible(true);
                label3_3.setVisible(true);
            }
        });

        labelCoNieDziala = new JLabel();
        labelCoNieDziala.setBounds(150, 550, 500, 30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
    }

    public static double round(double value) {
        int precision = 2;
        BigDecimal bigDecimal = new BigDecimal(value);
        bigDecimal = bigDecimal.setScale(precision, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }
}
