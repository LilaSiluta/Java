import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.ImageProducer;
import java.beans.PropertyChangeListener;
import java.time.LocalDate;

public class BunPanel
{
    JFrame frame;
    JLabel label, label1_1, label1, label2, label2_2, label3, label3_2, label4, label4_2, label5, label5_2, label6,
            label6_2, labDesc, labelCurrantBun, labelCoNieDziala;

    public BunPanel()
    {
        frame = new JFrame();

        JButton goBack = new JButton("Back");
        goBack.setBounds(40,550,120,30);
        goBack.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goBack);
        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PanelShop();
            }
        });

        JButton goToCart = new JButton("Go to cart");
        goToCart.setBounds(405,550,150,30);
        goToCart.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goToCart);
        goToCart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CartShop();
            }
        });

        label = new JLabel();
        label.setBounds(220,10,500,30);
        label.setFont(new Font("DialogInput", Font.BOLD, 30));
        label.setText("~ BUNS ~");
        frame.add(label);

        label1 = new JLabel();
        label1.setBounds(90,70,150,30);
        label1.setFont(new Font("DialogInput", Font.BOLD, 20));
        label1.setText("Currant bun");
        frame.add(label1);

        label1_1 = new JLabel();
        label1_1.setBounds(290,70,100,30);
        label1_1.setFont(new Font("DialogInput", Font.BOLD, 20));
        label1_1.setText("1.40$");
        frame.add(label1_1);

        JButton currantBun = new JButton("Add to cart");
        currantBun.setBounds(420,70,120,25);
        currantBun.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(currantBun);
        ImageIcon icon=new ImageIcon("dollar.png");
        currantBun.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one currant bun to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.40;
                CartShop.totalList.add("Currant bun");
            }
        });

        label2 = new JLabel();
        label2.setBounds(90,130,150,30);
        label2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2.setText("White loaf");
        frame.add(label2);

        label2_2 = new JLabel();
        label2_2.setBounds(290,130,100,30);
        label2_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2_2.setText("1.30$");
        frame.add(label2_2);

        JButton whiteLoaf = new JButton("Add to cart");
        whiteLoaf.setBounds(420,130,120,25);
        whiteLoaf.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(whiteLoaf);
        whiteLoaf.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one white loaf to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.30;
                CartShop.totalList.add("White loaf");
            }
        });

        label3 = new JLabel();
        label3.setBounds(90,190,180,30);
        label3.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3.setText("Jewish hallah");
        frame.add(label3);

        label3_2 = new JLabel();
        label3_2.setBounds(290,190,100,30);
        label3_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3_2.setText("1.10$");
        frame.add(label3_2);

        JButton jewishHallah = new JButton("Add to cart");
        jewishHallah.setBounds(420,190,120,25);
        jewishHallah.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(jewishHallah);
        jewishHallah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one jewish hallah to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.10;
                CartShop.totalList.add("Jewish hallah");
            }
        });

        label4 = new JLabel();
        label4.setBounds(90,250,150,30);
        label4.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4.setText("Bagel");
        frame.add(label4);

        label4_2 = new JLabel();
        label4_2.setBounds(290,250,100,30);
        label4_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4_2.setText("0.70$");
        frame.add(label4_2);

        JButton bagel = new JButton("Add to cart");
        bagel.setBounds(420,250,120,25);
        bagel.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(bagel);
        bagel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one bagel to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=0.70;
                CartShop.totalList.add("Bagel");
            }
        });

        label5 = new JLabel();
        label5.setBounds(90,310,150,30);
        label5.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5.setText("Baguette");
        frame.add(label5);

        label5_2 = new JLabel();
        label5_2.setBounds(290,310,100,30);
        label5_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5_2.setText("1.15$");
        frame.add(label5_2);

        JButton baguette = new JButton("Add to cart");
        baguette.setBounds(420,310,120,25);
        baguette.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(baguette);
        baguette.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one baguette to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.15;
                CartShop.totalList.add("Baguette");
            }
        });

        label6 = new JLabel();
        label6.setBounds(90,370,150,30);
        label6.setFont(new Font("DialogInput", Font.BOLD, 20));
        label6.setText("Cinnamon bun");
        frame.add(label6);

        label6_2 = new JLabel();
        label6_2.setBounds(290,370,100,30);
        label6_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label6_2.setText("1.60$");
        frame.add(label6_2);

        JButton cinnamonBun = new JButton("Add to cart");
        cinnamonBun.setBounds(420,370,120,25);
        cinnamonBun.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(cinnamonBun);
        cinnamonBun.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one cinnamon bun to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.60;
                CartShop.totalList.add("Cinnmon bun");
            }
        });

        JPanel description = new JPanel();
        TitledBorder title = BorderFactory.createTitledBorder( "DESCRIPTION OF THE PRODUCT");
        title.setTitleJustification(TitledBorder.CENTER);
        description.setBorder(title);
        description.setBounds(40, 410, 520, 130);
        description.setBackground(new Color(193, 37, 45));
        frame.add(description);

        LocalDate today = LocalDate.now();
        Bun.bunList.add(new Bun("Currant bun", today.plusDays(2), true, false, false, true, false, false, true, false));
        Bun.bunList.add(new Bun("White loaf", today.plusDays(3), true, false, false, true, false, false, false, true));
        Bun.bunList.add(new Bun("Jewish hallah", today.plusDays(2), true, false, false, true, false, false, true, false));
        Bun.bunList.add(new Bun("Bagel", today.plusDays(2), true, false, false, true, false, false, false, true));
        Bun.bunList.add(new Bun("Baguette", today.plusDays(3), true, false, false, true, false, false, false, true));
        Bun.bunList.add(new Bun("Cinnamon bun", today.plusDays(2), true, false, false, true, false, false, true, false));

        labDesc = new JLabel();
        description.add(labDesc);
        labDesc.setBounds(40, 400, 480, 80);
        label1.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bun.bunList.get(0).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label2.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bun.bunList.get(1).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label3.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bun.bunList.get(2).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label4.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bun.bunList.get(3).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label5.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bun.bunList.get(4).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label6.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bun.bunList.get(5).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });

        labelCoNieDziala= new JLabel();
        labelCoNieDziala.setBounds(150,550,500,30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600,630);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

    }


}
