import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;

public class CakePanel
{
    JFrame frame;
    JLabel label, label1_1, label1, label2, label2_2, label3, label3_2, label4, label4_2, label5, label5_2,
            labDesc, labelCoNieDziala;

    public CakePanel()
    {
        frame = new JFrame();

        LocalDate today = LocalDate.now();
        Cake.cakeList.add(new Cake("Apple pie", today.plusDays(3), true, true, false, false, true, false, true,false));
        Cake.cakeList.add(new Cake("Cheesecake", today.plusDays(3), true, false, true, false, true, false, true,false));
        Cake.cakeList.add(new Cake("Banana and flour", today.plusDays(3), true, false, true, false, true, false, true,false));
        Cake.cakeList.add(new Cake("Brownie", today.plusDays(3), true, false, false, false, true, false, true,false));
        Cake.cakeList.add(new Cake("Bundt cake", today.plusDays(3), true, true, false, false, true, false, true,false));

        JButton goBack = new JButton("Back");
        goBack.setBounds(40,545,120,30);
        goBack.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goBack);
        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PanelShop();
            }
        });

        JButton goToCart = new JButton("Go to cart");
        goToCart.setBounds(405,545,150,30);
        goToCart.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goToCart);
        goToCart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CartShop();
            }
        });

        label = new JLabel();
        label.setBounds(230,20,500,30);
        label.setFont(new Font("DialogInput", Font.BOLD, 30));
        label.setText("~ CAKE ~");
        frame.add(label);

        label1 = new JLabel();
        label1.setBounds(90,100,150,30);
        label1.setFont(new Font("DialogInput", Font.BOLD, 20));
        label1.setText("Applepie");
        frame.add(label1);

        label1_1 = new JLabel();
        label1_1.setBounds(310,100,100,30);
        label1_1.setFont(new Font("DialogInput", Font.BOLD, 20));
        label1_1.setText("15$");
        frame.add(label1_1);

        JButton applepie = new JButton("Add to cart");
        applepie.setBounds(420,100,120,25);
        applepie.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(applepie);
        ImageIcon icon=new ImageIcon("dollar.png");
        applepie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one applepie to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=15.00;
                CartShop.totalList.add("Applepie");
            }
        });

        label2 = new JLabel();
        label2.setBounds(90,160,150,30);
        label2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2.setText("Cheesecake");
        frame.add(label2);

        label2_2 = new JLabel();
        label2_2.setBounds(310,160,100,30);
        label2_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2_2.setText("19$");
        frame.add(label2_2);

        JButton cheesecake = new JButton("Add to cart");
        cheesecake.setBounds(420,160,120,25);
        cheesecake.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(cheesecake);
        cheesecake.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one cheesecake to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=19.00;
                CartShop.totalList.add("Cheesecake");
            }
        });

        label3 = new JLabel();
        label3.setBounds(90,220,200,30);
        label3.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3.setText("Banana and flour");
        frame.add(label3);

        label3_2 = new JLabel();
        label3_2.setBounds(310,220,100,30);
        label3_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3_2.setText("13$");
        frame.add(label3_2);

        JButton bananaAndFlour = new JButton("Add to cart");
        bananaAndFlour.setBounds(420,220,120,25);
        bananaAndFlour.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(bananaAndFlour);
        bananaAndFlour.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one banana and flour to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=13.00;
                CartShop.totalList.add("Banana and flour");
            }
        });

        label4 = new JLabel();
        label4.setBounds(90,280,150,30);
        label4.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4.setText("Brownie");
        frame.add(label4);

        label4_2 = new JLabel();
        label4_2.setBounds(310,280,100,30);
        label4_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4_2.setText("12$");
        frame.add(label4_2);

        JButton brownie = new JButton("Add to cart");
        brownie.setBounds(420,280,120,25);
        brownie.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(brownie);
        brownie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one brownie to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=12.00;
                CartShop.totalList.add("Brownie");
            }
        });

        label5 = new JLabel();
        label5.setBounds(90,340,150,30);
        label5.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5.setText("Bundt cake");
        frame.add(label5);

        label5_2 = new JLabel();
        label5_2.setBounds(310,340,100,30);
        label5_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5_2.setText("17$");
        frame.add(label5_2);

        JButton bundtCake = new JButton("Add to cart");
        bundtCake.setBounds(420,340,120,25);
        bundtCake.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(bundtCake);
        bundtCake.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one bundt cake to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=17.00;
                CartShop.totalList.add("Bundt cake");
            }
        });

        JPanel description = new JPanel();
        TitledBorder title = BorderFactory.createTitledBorder( "DESCRIPTION OF THE PRODUCT");
        title.setTitleJustification(TitledBorder.CENTER);
        description.setBorder(title);
        description.setBounds(40, 400, 520, 130);
        description.setBackground(new Color(193, 37, 45));
        frame.add(description);

        labDesc = new JLabel();
        description.add(labDesc);
        labDesc.setBounds(40, 400, 480, 120);
        label1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cake.cakeList.get(0).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cake.cakeList.get(1).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cake.cakeList.get(2).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cake.cakeList.get(3).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cake.cakeList.get(4).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });

        labelCoNieDziala= new JLabel();
        labelCoNieDziala.setBounds(150,550,500,30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600,630);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

    }


}
