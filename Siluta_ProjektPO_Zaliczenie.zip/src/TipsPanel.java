import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class TipsPanel
{
    JFrame frame;
    JLabel label, label2, tipsPicture, labelCoNieDziala;
    public static int choice;

    public TipsPanel()
    {
        frame = new JFrame();

        JButton donate = new JButton("DONATE");
        donate.setBounds(220,190,120,25);
        donate.setFont(new Font("DialogInput", Font.BOLD, 15));
        frame.add(donate);
        ImageIcon icon=new ImageIcon("dollar.png");
        donate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(null, "Thank You for Your donation!", "Donation", JOptionPane.INFORMATION_MESSAGE,icon);
                choice = JOptionPane.showOptionDialog(null, "Thank You for Your donation!", "Tip", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, icon, null, null);
                if (choice ==JOptionPane.YES_OPTION)
                {
                    frame.dispose();
                }
            }
        });

        label = new JLabel();
        label.setBounds(190,20,500,150);
        label.setFont(new Font("DialogInput", Font.BOLD, 17));
        label.setText("<html>You can donate 5% <br>    of your total cost <br>for poor students</br></html>");
        frame.add(label);

        label2 = new JLabel();
        label2.setBounds(265,80,500,150);
        label2.setFont(new Font("DialogInput", Font.BOLD, 25));
        label2.setText(":)");
        frame.add(label2);

        tipsPicture = new JLabel(new ImageIcon("tips.png"));
        tipsPicture.setBounds(0,20,200,200);
        frame.add(tipsPicture);

        labelCoNieDziala = new JLabel();
        labelCoNieDziala.setBounds(150, 550, 500, 30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(400, 300);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
    }
}
