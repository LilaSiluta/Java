import jdk.jfr.Description;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;

public class BreadPanel
{
    JFrame frame;
    JLabel label, label1_1, label1, label2, label2_2, label3, label3_2, label4, label4_2, label5, label5_2,
            labDesc, labelCoNieDziala;

    public BreadPanel()
    {
        frame = new JFrame();

        JButton goBack = new JButton("Back");
        goBack.setBounds(40,550,120,30);
        goBack.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goBack);
        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PanelShop();
            }
        });

        JButton goToCart = new JButton("Go to cart");
        goToCart.setBounds(410,550,150,30);
        goToCart.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goToCart);
        goToCart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CartShop();
            }
        });

        label = new JLabel();
        label.setBounds(210,20,500,30);
        label.setFont(new Font("DialogInput", Font.BOLD, 30));
        label.setText("~ BREAD ~");
        frame.add(label);

        label1 = new JLabel();
        label1.setBounds(90,100,150,30);
        label1.setFont(new Font("DialogInput", Font.BOLD, 20));
        label1.setText("Rye bread");
        frame.add(label1);

        label1_1 = new JLabel();
        label1_1.setBounds(290,100,100,30);
        label1_1.setFont(new Font("DialogInput", Font.BOLD, 20));
        label1_1.setText("2.25$");
        frame.add(label1_1);

        JButton ryeBread = new JButton("Add to cart");
        ryeBread.setBounds(420,100,120,25);
        ryeBread.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(ryeBread);
        ImageIcon icon=new ImageIcon("dollar.png");
        ryeBread.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one rye bread to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=2.25;
                CartShop.totalList.add("Rye bread");
            }
        });

        label2 = new JLabel();
        label2.setBounds(90,160,150,30);
        label2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2.setText("Wheat bread");
        frame.add(label2);

        label2_2 = new JLabel();
        label2_2.setBounds(290,160,100,30);
        label2_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2_2.setText("1.30$");
        frame.add(label2_2);

        JButton wheatBread = new JButton("Add to cart");
        wheatBread.setBounds(420,160,120,25);
        wheatBread.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(wheatBread);
        wheatBread.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one wheat bread to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.30;
                CartShop.totalList.add("Wheat bread");
            }
        });

        label3 = new JLabel();
        label3.setBounds(90,220,150,30);
        label3.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3.setText("Banana bread");
        frame.add(label3);

        label3_2 = new JLabel();
        label3_2.setBounds(290,220,100,30);
        label3_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3_2.setText("2.00$");
        frame.add(label3_2);

        JButton bananaBread = new JButton("Add to cart");
        bananaBread.setBounds(420,220,120,25);
        bananaBread.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(bananaBread);
        bananaBread.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one banana bread to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=2.00;
                CartShop.totalList.add("Banana bread");
            }
        });

        label4 = new JLabel();
        label4.setBounds(90,280,150,30);
        label4.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4.setText("Black bread");
        frame.add(label4);

        label4_2 = new JLabel();
        label4_2.setBounds(290,280,100,30);
        label4_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4_2.setText("2.60$");
        frame.add(label4_2);

        JButton blackBread = new JButton("Add to cart");
        blackBread.setBounds(420,280,120,25);
        blackBread.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(blackBread);
        blackBread.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one black bread to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=2.60;
                CartShop.totalList.add("Black bread");
            }
        });

        label5 = new JLabel();
        label5.setBounds(90,340,150,30);
        label5.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5.setText("White bread");
        frame.add(label5);

        label5_2 = new JLabel();
        label5_2.setBounds(290,340,100,30);
        label5_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5_2.setText("1.90$");
        frame.add(label5_2);

        JButton whiteBread = new JButton("Add to cart");
        whiteBread.setBounds(420,340,120,25);
        whiteBread.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(whiteBread);
        whiteBread.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one white bread to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.40;
                CartShop.totalList.add("White bread");
            }
        });

        JPanel description = new JPanel();
        TitledBorder title = BorderFactory.createTitledBorder( "DESCRIPTION OF THE PRODUCT");
        title.setTitleJustification(TitledBorder.CENTER);
        description.setBorder(title);
        description.setBounds(40, 400, 520, 135);
        description.setBackground(new Color(193, 37, 45));
        frame.add(description);

        LocalDate today = LocalDate.now();
        Bread.breadList.add(new Bread("Rye bread", "Rye flour", today.plusDays(3), true, true, true, false, false, false, false,true));
        Bread.breadList.add(new Bread("Wheat bread", "Wheat flour", today.plusDays(3), true, false, true, false, false, false, false,true));
        Bread.breadList.add(new Bread("Banana bread", "Wheat flour and banana", today.plusDays(3), true, false, true, false, true, false, true,false));
        Bread.breadList.add(new Bread("Black bread", "Rye flour", today.plusDays(3), true, false, true, false, false, false, false,true));
        Bread.breadList.add(new Bread("White bread", "Wheat flour", today.plusDays(3), true, true, true, false, false, false, false,true));
        labDesc = new JLabel();
        description.add(labDesc);
        labDesc.setBounds(40, 400, 480, 80);
        label1.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bread.breadList.get(0).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label2.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bread.breadList.get(1).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label3.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bread.breadList.get(2).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label4.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bread.breadList.get(3).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label5.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Bread.breadList.get(4).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });

        labelCoNieDziala= new JLabel();
        labelCoNieDziala.setBounds(150,550,500,30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600,630);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
    }


}
