import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;

public class CookiePanel
{
    JFrame frame;
    JLabel label, label1_1, label1, label2, label2_2, label3, label3_2, label4, label4_2, label5, label5_2,
            label6, label6_2, label7, label7_2, labDesc, labelCoNieDziala;

    public CookiePanel()
    {
        frame = new JFrame();

        JButton goBack = new JButton("Back");
        goBack.setBounds(35,550,120,30);
        goBack.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goBack);
        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PanelShop();
            }
        });

        JButton goToCart = new JButton("Go to cart");
        goToCart.setBounds(405,550,150,30);
        goToCart.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goToCart);
        goToCart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CartShop();
            }
        });

        label = new JLabel();
        label.setBounds(220,10,500,30);
        label.setFont(new Font("DialogInput", Font.BOLD, 30));
        label.setText("~ COOKIES ~");
        frame.add(label);

        label1 = new JLabel();
        label1.setBounds(50,55,250,30);
        label1.setFont(new Font("DialogInput", Font.BOLD, 18));
        label1.setText("Chocolate chip cookie");
        frame.add(label1);

        label1_1 = new JLabel();
        label1_1.setBounds(310,55,150,30);
        label1_1.setFont(new Font("DialogInput", Font.BOLD, 17));
        label1_1.setText("1.20$");
        frame.add(label1_1);

        JButton chocolateChipCookie = new JButton("Add to cart");
        chocolateChipCookie.setBounds(420,55,120,25);
        chocolateChipCookie.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(chocolateChipCookie);
        ImageIcon icon=new ImageIcon("dollar.png");
        chocolateChipCookie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one chocolate chip cookie to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.20;
                CartShop.totalList.add("Chocolate chip cookie");
            }
        });

        label2 = new JLabel();
        label2.setBounds(50,105,200,30);
        label2.setFont(new Font("DialogInput", Font.BOLD, 17));
        label2.setText("Vanilla cookie");
        frame.add(label2);

        label2_2 = new JLabel();
        label2_2.setBounds(310,105,100,30);
        label2_2.setFont(new Font("DialogInput", Font.BOLD, 17));
        label2_2.setText("1.20$");
        frame.add(label2_2);

        JButton vanillaCookie = new JButton("Add to cart");
        vanillaCookie.setBounds(420,105,120,25);
        vanillaCookie.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(vanillaCookie);
        vanillaCookie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one vanilla cookie to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.20;
                CartShop.totalList.add("Vanilla cookie");
            }
        });

        label3 = new JLabel();
        label3.setBounds(50,155,250,30);
        label3.setFont(new Font("DialogInput", Font.BOLD, 17));
        label3.setText("Oatmeal risin cookie");
        frame.add(label3);

        label3_2 = new JLabel();
        label3_2.setBounds(310,155,100,30);
        label3_2.setFont(new Font("DialogInput", Font.BOLD, 17));
        label3_2.setText("1.70$");
        frame.add(label3_2);

        JButton oatmealRaisinCookie = new JButton("Add to cart");
        oatmealRaisinCookie.setBounds(420,155,120,25);
        oatmealRaisinCookie.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(oatmealRaisinCookie);
        oatmealRaisinCookie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one oatmeal raisin cookie to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.70;
                CartShop.totalList.add("Oatmeal raisin cookie");
            }
        });

        label4 = new JLabel();
        label4.setBounds(50,205,250,30);
        label4.setFont(new Font("DialogInput", Font.BOLD, 17));
        label4.setText("Peanut butter cookie");
        frame.add(label4);

        label4_2 = new JLabel();
        label4_2.setBounds(310,205,100,30);
        label4_2.setFont(new Font("DialogInput", Font.BOLD, 17));
        label4_2.setText("1.10$");
        frame.add(label4_2);

        JButton peanutButterCookie = new JButton("Add to cart");
        peanutButterCookie.setBounds(420,205,120,25);
        peanutButterCookie.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(peanutButterCookie);
        peanutButterCookie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one peanutbutter cookie to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.10;
                CartShop.totalList.add("Peanutbutter cookie");
            }
        });

        label5 = new JLabel();
        label5.setBounds(50,255,200,30);
        label5.setFont(new Font("DialogInput", Font.BOLD, 17));
        label5.setText("Sugar cookie");
        frame.add(label5);

        label5_2 = new JLabel();
        label5_2.setBounds(310,255,100,30);
        label5_2.setFont(new Font("DialogInput", Font.BOLD, 17));
        label5_2.setText("1.00$");
        frame.add(label5_2);

        JButton sugarCookie = new JButton("Add to cart");
        sugarCookie.setBounds(420,255,120,25);
        sugarCookie.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(sugarCookie);
        sugarCookie.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one sugar cookie to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.00;
                CartShop.totalList.add("Sugar cookie");
            }
        });

        label6 = new JLabel();
        label6.setBounds(50,305,150,30);
        label6.setFont(new Font("DialogInput", Font.BOLD, 17));
        label6.setText("Biscotti");
        frame.add(label6);

        label6_2 = new JLabel();
        label6_2.setBounds(310,305,100,30);
        label6_2.setFont(new Font("DialogInput", Font.BOLD, 17));
        label6_2.setText("0.90$");
        frame.add(label6_2);

        JButton biscotti = new JButton("Add to cart");
        biscotti.setBounds(420,305,120,25);
        biscotti.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(biscotti);
        biscotti.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one biscotti to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=0.90;
                CartShop.totalList.add("Biscotti");
            }
        });

        label7 = new JLabel();
        label7.setBounds(50,355,200,30);
        label7.setFont(new Font("DialogInput", Font.BOLD, 17));
        label7.setText("Fortune cookies");
        frame.add(label7);

        label7_2 = new JLabel();
        label7_2.setBounds(310,355,100,30);
        label7_2.setFont(new Font("DialogInput", Font.BOLD, 17));
        label7_2.setText("2.00$");
        frame.add(label7_2);

        JButton fortuneCookies = new JButton("Add to cart");
        fortuneCookies.setBounds(420,355,120,25);
        fortuneCookies.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(fortuneCookies);
        fortuneCookies.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added one fortune cookie to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=2.00;
                CartShop.totalList.add("Fortune cookies");
            }
        });

        JPanel description = new JPanel();
        TitledBorder title = BorderFactory.createTitledBorder( "DESCRIPTION OF THE PRODUCT");
        title.setTitleJustification(TitledBorder.CENTER);
        description.setBorder(title);
        description.setBounds(35, 405, 520, 130);
        description.setBackground(new Color(193, 37, 45));
        frame.add(description);

        LocalDate today = LocalDate.now();
        Cookie.cookieList.add(new Cookie("Chocolate chip cookie", today.plusDays(3), true, false, false, false, false, true, true,false));
        Cookie.cookieList.add(new Cookie("Vanilla cookie", today.plusDays(3), true, false, false, false, false, true, true,false));
        Cookie.cookieList.add(new Cookie("Oatmeal raisin cookie", today.plusDays(3), true, false, false, false, false, true, true,false));
        Cookie.cookieList.add(new Cookie("Peanut butter cookie", today.plusDays(3), true, false, false, false, false, true, true,false));
        Cookie.cookieList.add(new Cookie("Sugar cookie", today.plusDays(3), true, false, false, false, false, true, true,false));
        Cookie.cookieList.add(new Cookie("Biscotti", today.plusDays(3), true, false, false, false, false, true, true,false));
        Cookie.cookieList.add(new Cookie("Fortune cookies", today.plusDays(3), true, false, false, false, false, true, true,false));

        labDesc = new JLabel();
        description.add(labDesc);
        labDesc.setBounds(40, 400, 480, 80);
        label1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cookie.cookieList.get(0).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cookie.cookieList.get(1).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cookie.cookieList.get(2).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cookie.cookieList.get(3).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cookie.cookieList.get(4).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cookie.cookieList.get(5).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });
        label7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e)
            {
                labDesc.setText(Cookie.cookieList.get(6).toString());
            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                labDesc.setText(" ");
            }
        });

        labelCoNieDziala= new JLabel();
        labelCoNieDziala.setBounds(150,550,500,30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600,630);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

    }


}
