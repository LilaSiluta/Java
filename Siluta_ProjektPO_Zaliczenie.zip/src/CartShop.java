import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class CartShop
{
    int i;
    JFrame frame;
    JLabel label, label2, label3, labelCoNieDziala;
    public static double cost=0.00;
    public static ArrayList<Object> totalList=new ArrayList<>();
    JTextArea area;

    public CartShop()
    {
        frame = new JFrame();

        JButton goBack = new JButton("Back");
        goBack.setBounds(30,460,120,30);
        goBack.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goBack);
        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PanelShop();
            }
        });

        JButton payment = new JButton("Payment");
        payment.setBounds(420,460,120,30);
        payment.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(payment);
        payment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PaymentPanel();
                new TipsPanel();
            }
        });

        label = new JLabel();
        label.setBounds(250,10,500,30);
        label.setFont(new Font("DialogInput", Font.BOLD, 30));
        label.setText("CART:");
        frame.add(label);


        label2 = new JLabel();
        label2.setBounds(270,410,200,30);
        label2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2.setText("Total cost:");
        frame.add(label2);

        label3 = new JLabel();
        label3.setBounds(420,410,500,30);
        label3.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3.setText(cost+" $");
        frame.add(label3);

        JPanel description = new JPanel();
        TitledBorder title = BorderFactory.createTitledBorder( "THE LIST OF YOUR PRODUCTS");
        title.setTitleJustification(TitledBorder.CENTER);
        description.setBorder(title);
        description.setBounds(30, 110, 520, 290);
        description.setBackground(new Color(193, 37, 45));
        frame.add(description);

        area = new JTextArea();
        JScrollPane scroll= new JScrollPane (area);
        scroll.setBounds(60,130,480,250);
        scroll.setBackground(new Color(193, 37, 45));
        area.setEditable(false);
        area.setBounds(60,130,480,240);
        area.setBackground(new Color(193, 37, 45));
        area.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(scroll);

        JButton loadList = new JButton("Load list of Your products");
        loadList.setBounds(150,60,300,25);
        loadList.setFont(new Font("DialogInput", Font.BOLD, 15));
        loadList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for(i=0; i<totalList.size(); i++)
                {
                   area.append(totalList.get(i)+"\n");
                }
                loadList.setEnabled(false);
            }
        });
        frame.add(loadList);

        labelCoNieDziala = new JLabel();
        labelCoNieDziala.setBounds(150, 550, 500, 30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
    }
}
