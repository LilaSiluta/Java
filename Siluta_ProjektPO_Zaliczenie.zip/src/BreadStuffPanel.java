import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BreadStuffPanel
{
    JFrame frame;
    JLabel label, label1_1, label1, label2, label2_2, label3, label3_3, label4, label4_4, label5, label5_5, label6,
            label6_6, labelCoNieDziala;
    int i;

    public BreadStuffPanel()
    {
        frame = new JFrame();

        JButton goBack = new JButton("Back");
        goBack.setBounds(40,450,120,30);
        goBack.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goBack);
        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PanelShop();
            }
        });

        JButton goToCart = new JButton("Go to cart");
        goToCart.setBounds(400,450,150,30);
        goToCart.setFont(new Font("DialogInput", Font.BOLD, 17));
        frame.add(goToCart);
        goToCart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CartShop();
            }
        });

        label1 = new JLabel();
        label1.setBounds(80,20,500,30);
        label1.setFont(new Font("DialogInput", Font.BOLD, 30));
        label1.setText("~ BREADSTUFF PRODUCTS ~");
        frame.add(label1);

        label1 = new JLabel();
        label1.setBounds(40,100,150,30);
        label1.setFont(new Font("DialogInput", Font.BOLD, 20));
        label1.setText("Jar of honey");
        frame.add(label1);

        label1_1 = new JLabel();
        label1_1.setBounds(290,100,100,30);
        label1_1.setFont(new Font("DialogInput", Font.BOLD, 20));
        label1_1.setText("4.00$");
        frame.add(label1_1);

        JButton honey = new JButton("Add to cart");
        honey.setBounds(420,100,120,25);
        honey.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(honey);
        ImageIcon icon=new ImageIcon("dollar.png");
        honey.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added a jar of honey to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=4.00;
                CartShop.totalList.add("Jar of honey");
            }
        });

        label2 = new JLabel();
        label2.setBounds(40,150,250,30);
        label2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2.setText("Jar of mayonnaise");
        frame.add(label2);

        label2_2 = new JLabel();
        label2_2.setBounds(290,150,100,30);
        label2_2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2_2.setText("3.25$");
        frame.add(label2_2);

        JButton jarOfMayonnaise = new JButton("Add to cart");
        jarOfMayonnaise.setBounds(420,150,120,25);
        jarOfMayonnaise.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(jarOfMayonnaise);
        jarOfMayonnaise.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added a jar of mayonnaise to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=3.25;
                CartShop.totalList.add("Jar of mayonnaise");
            }
        });

        label3 = new JLabel();
        label3.setBounds(40,200,250,30);
        label3.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3.setText("Flour");
        frame.add(label3);

        label3_3 = new JLabel();
        label3_3.setBounds(290,200,100,30);
        label3_3.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3_3.setText("2.40$");
        frame.add(label3_3);

        JButton flour = new JButton("Add to cart");
        flour.setBounds(420,200,120,25);
        flour.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(flour);
        flour.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added flour to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=2.40;
                CartShop.totalList.add("Flour");
            }
        });

        label4 = new JLabel();
        label4.setBounds(40,250,250,30);
        label4.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4.setText("Sugar");
        frame.add(label4);

        label4_4 = new JLabel();
        label4_4.setBounds(290,250,100,30);
        label4_4.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4_4.setText("2.00$");
        frame.add(label4_4);

        JButton sugar = new JButton("Add to cart");
        sugar.setBounds(420,250,120,25);
        sugar.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(sugar);
        sugar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added sugar to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=2.00;
                CartShop.totalList.add("Sugar");
            }
        });

        label5 = new JLabel();
        label5.setBounds(40,300,250,30);
        label5.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5.setText("Baking powder");
        frame.add(label5);

        label5_5 = new JLabel();
        label5_5.setBounds(290,300,100,30);
        label5_5.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5_5.setText("1.25$");
        frame.add(label5_5);

        JButton bakingPowder = new JButton("Add to cart");
        bakingPowder.setBounds(420,300,120,25);
        bakingPowder.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(bakingPowder);
        bakingPowder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added baking powder to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=1.25;
                CartShop.totalList.add("Baking powder");
            }
        });

        label6 = new JLabel();
        label6.setBounds(40,350,250,30);
        label6.setFont(new Font("DialogInput", Font.BOLD, 20));
        label6.setText("Soda");
        frame.add(label6);

        label6_6 = new JLabel();
        label6_6.setBounds(290,350,100,30);
        label6_6.setFont(new Font("DialogInput", Font.BOLD, 20));
        label6_6.setText("0.85$");
        frame.add(label6_6);

        JButton soda = new JButton("Add to cart");
        soda.setBounds(420,350,120,25);
        soda.setFont(new Font("DialogInput", Font.BOLD, 12));
        frame.add(soda);
        soda.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "You added soda to your cart.", "Added to a cart", JOptionPane.INFORMATION_MESSAGE,icon);
                CartShop.cost+=0.85;
                CartShop.totalList.add("Soda");
            }
        });

        labelCoNieDziala= new JLabel();
        labelCoNieDziala.setBounds(150,550,500,30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600,550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
    }
}
