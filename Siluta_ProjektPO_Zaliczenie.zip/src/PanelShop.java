import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanelShop
{
    JFrame frame;
    JLabel label, label2, labelCoNieDziala, label3, label4, label5, label6,
            cakePicture, breadPicture, bunPicture, cookiePicture, breadStuffPicture;

    public PanelShop()
    {
        frame = new JFrame();

        label = new JLabel();
        label.setBounds(100,20,400,50);
        label.setFont(new Font("DialogInput", Font.BOLD, 30));
        label.setText("Choose main category:");
        frame.add(label);

        breadPicture = new JLabel(new ImageIcon("bread.png"));
        breadPicture.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                new BreadPanel();
            }
        });
        breadPicture.setBounds(0,50,200,200);
        frame.add(breadPicture);

        label2 = new JLabel();
        label2.setBounds(70,205,400,50);
        label2.setFont(new Font("DialogInput", Font.BOLD, 20));
        label2.setText("Bread");
        frame.add(label2);

        bunPicture = new JLabel(new ImageIcon("bun.png"));
        bunPicture.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                new BunPanel();
            }
        });
        bunPicture.setBounds(200,50,200,200);
        frame.add(bunPicture);

        label3 = new JLabel();
        label3.setBounds(280,205,400,50);
        label3.setFont(new Font("DialogInput", Font.BOLD, 20));
        label3.setText("Bun");
        frame.add(label3);

        cookiePicture = new JLabel(new ImageIcon("cookie.png"));
        cookiePicture.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                new CookiePanel();
            }
        });
        cookiePicture.setBounds(400,50,200,200);
        frame.add(cookiePicture);

        label4 = new JLabel();
        label4.setBounds(460,205,400,50);
        label4.setFont(new Font("DialogInput", Font.BOLD, 20));
        label4.setText("Cookies");
        frame.add(label4);

        cakePicture = new JLabel(new ImageIcon("cake.png"));
        cakePicture.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                new CakePanel();
            }
        });
        cakePicture.setBounds(90,250,200,200);
        frame.add(cakePicture);

        label5 = new JLabel();
        label5.setBounds(165,430,400,50);
        label5.setFont(new Font("DialogInput", Font.BOLD, 20));
        label5.setText("Cake");
        frame.add(label5);

        breadStuffPicture = new JLabel(new ImageIcon("breadStuff.png"));
        breadStuffPicture.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                new BreadStuffPanel();
            }
        });
        breadStuffPicture.setBounds(320,260,200,200);
        frame.add(breadStuffPicture);

        label6 = new JLabel();
        label6.setBounds(355,430,400,50);
        label6.setFont(new Font("DialogInput", Font.BOLD, 20));
        label6.setText("Bread Stuff");
        frame.add(label6);

        labelCoNieDziala= new JLabel();
        labelCoNieDziala.setBounds(150,550,500,30);
        labelCoNieDziala.setFont(new Font("DialogInput", Font.BOLD, 20));
        labelCoNieDziala.setText(" ");
        frame.add(labelCoNieDziala);

        ImageIcon image = new ImageIcon("zdj_1.png");
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(new Color(193, 37, 45));
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setTitle("HappyOven");
        frame.setSize(600,550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
    }
}