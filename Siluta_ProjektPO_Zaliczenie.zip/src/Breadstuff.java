import java.time.LocalDate;

public class Breadstuff
{
    String kind;
    String flour;
    LocalDate expirationDate;
    boolean fresh;
    boolean cut;
    boolean bread;
    boolean bun;
    boolean cake;
    boolean cookie;
    boolean sweet;
    boolean savoury;

    @Override
    public String toString() {
        return "<html><table><tr><td>1. Kind: "+this.kind+"    </td><td>        5. Cut: "+this.cut+"</td><td>        9. Cookie: "+this.cookie+"</td></tr>" +
                "<tr><td>2. Flour: "+this.flour+"</td><td>6. Bread: "+this.bread+"</td><td>        10. Sweet: "+this.sweet+"</td></tr>" +
                "<tr><td>3. Expiration date: "+this.expirationDate+"</td><td>        7. Bun: "+this.bun+"</td><td>        11. Savoury: "+this.savoury+"</td></tr>" +
                "<tr><td>4. Fresh: "+this.fresh+"</td><td>        8. Cake: "+this.cake+"</td><td></td></tr>" +
                "</table></html>";
    }
}

